

import React from "react";
import todoList from './test/TodoList';
import TodoList from "./test/TodoList";

function App() {
    return (
        <div>
            <TodoList />
        </div>
    );
}

export default App;



